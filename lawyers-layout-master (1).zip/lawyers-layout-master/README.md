# Lawyers

Projeto criado para fins de estudo. Consiste em um template responsivo focado em escritórios de advocacia, é uma landing page simples, que apresenta as áreas de atuação do escritório, um pouco sobre ele e sobre quem ali trabalha, com um formulário de contato ao final. O design é bem moderno, fazendo uso de tendencias como o flat design e material design para a criação de profundidade em alguns elementos por meio de sombras.

## Técnologias utilizadas

-   HTML 5
-   CSS 3
-   JavaScript ES6+
